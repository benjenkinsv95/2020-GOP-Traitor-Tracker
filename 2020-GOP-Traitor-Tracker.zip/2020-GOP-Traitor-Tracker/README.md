# 2020-GOP-Traitor-Tracker

An extension that keeps track of the traitors that tried to overthrow the 2020 election by disenfranchising the voters of 4 entire states. 